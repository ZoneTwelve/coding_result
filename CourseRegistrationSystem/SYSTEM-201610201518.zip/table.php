﻿<style>
tr td{
    border-width:5px;	
    border-style:ridge;
	margin:0;
	padding:25;
}
</style>
<?php
//判斷選課內容
echo '<table><tr><th>節數</th><th>週一</th><th>週二</th><th>週三</th><th>週四</th><th>週五</th></tr>';
echo '<tr><td>第一節</td>
    <td id="11">$100</td>
    <td id="21">$100</td>
    <td id="31">$100</td>
    <td id="41">$100</td>
    <td id="51">$100</td></tr>';
echo '<tr><td>第二節</td>
    <td id="12">$80a</td>
    <td id="22">$80</td>
    <td id="32">$80b</td>
    <td id="42">$80</td>
    <td id="52">$80c</td></tr>';
echo ' <tr><td>第三節</td>
	<td id="13"></td>
 	<td id="23"></td>
 	<td id="33"></td>
 	<td id="43"></td>
 	<td id="53"></td></tr>';
echo ' <tr><td>第四節</td>
 	<td></td>
 	<td></td>
 	<td></td>
 	<td></td>
 	<td></td></tr>';
echo ' <tr><td>第五節</td>
 	<td></td>
 	<td></td>
 	<td></td>
 	<td></td>
 	<td></td></tr>';
echo ' <tr><td>第六節</td>
 	<td></td>
 	<td></td>
 	<td></td>
 	<td></td>
 	<td></td></tr>';
echo ' <tr><td>第七節</td>
 	<td></td>
 	<td></td>
 	<td></td>
 	<td></td>
 	<td></td></tr>';
echo '</table>';

?>